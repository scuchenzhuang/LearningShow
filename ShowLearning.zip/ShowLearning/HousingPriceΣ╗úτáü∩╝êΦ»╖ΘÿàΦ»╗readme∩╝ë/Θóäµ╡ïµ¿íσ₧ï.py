import numpy as np
import pandas as pd
import matplotlib.pylab as plt
import seaborn as sns
import warnings
import mysql.connector
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_selection import SelectFromModel
def feature_selection(data):
    # 将数据集分成特征和目标两部分
    X = data.drop(['deal_price'], axis=1)
    y = data['deal_price']
    print(X.columns)
    # 使用随机森林模型进行特征选择
    rf = RandomForestRegressor(n_estimators=100, random_state=42)
    rf.fit(X, y)

    # 提取特征的重要性
    feature_importances = pd.DataFrame({'feature': X.columns, 'importance': rf.feature_importances_})
    feature_importances = feature_importances.sort_values('importance', ascending=False)

    # 打印特征重要性
    #print(feature_importances)

    # 选择最重要的特征
    sfm = SelectFromModel(rf, threshold='median')
    sfm.fit(X, y)
    X_selected = sfm.transform(X)

    # 打印选择的特征
    print("Selected features:")
    feature_list = []
    type_list = []
    for i in range(X_selected.shape[1]):
        cur = X.columns[sfm.get_support()][i]
        print("Feature {}: {}".format(i+1, cur ))
        feature_list.append(str(cur))

    # 返回选择的特征和目标变量
    return X_selected, y,feature_list
def delete_value(data,param):
    # 计算住房面积的均值和标准差
    param_value = param
    area_mean = data[param_value].mean()
    area_std = data[param_value].std()

    # 计算房屋价格的均值和标准差
    price_mean = data['deal_price'].mean()
    price_std = data['deal_price'].std()

    # 计算异常值的范围
    area_lower_bound = area_mean - 3 * area_std
    area_upper_bound = area_mean + 3 * area_std
    price_lower_bound = price_mean - 3 * price_std
    price_upper_bound = price_mean + 3 * price_std

    # 去除住房面积和房屋价格的异常值
    data = data[(data[param_value] > area_lower_bound) & (data[param_value] < area_upper_bound)]
    data = data[(data['deal_price'] > price_lower_bound) & (data['deal_price'] < price_upper_bound)]
    data.reset_index(inplace=True)
    data.drop(columns=['index'], inplace=True)
    return data
def one_hot(data,param):
    # 使用 get_dummies() 函数对 region 列进行编码
    region_encoded = pd.get_dummies(data[param])#, prefix=param
    # prefix 参数指定生成的编码列的前缀
    # 将编码列与原始数据集进行合并
    data_encoded = pd.concat([data, region_encoded], axis=1)
    data_encoded.drop(param, axis=1, inplace=True)
    return data_encoded

def data_processing():
    conn = mysql.connector.connect(host='localhost',
                                   user='root',
                                   passwd='dbuserdbuser',
                                   db='HousingPrice',auth_plugin = 'mysql_native_password')  # 链接本地数据库
    sql = 'select * from house'  # sql语句
    data = pd.read_sql(sql, conn)  # 获取数据
    data.drop(columns=['id'],inplace=True)
    #此次模型涉及的数据没有空值，也没有重复值
    data.dropna(axis=0, how='any', inplace=True)
    #去除异常值，用均值加减3倍标准差法
    data = delete_value(data,'area')
    data = one_hot(data,'district')
    data = one_hot(data, 'floor')
    data = one_hot(data,'architecture')
    data = one_hot(data, 'decoration')
    data = one_hot(data, 'house_structure')
    data = one_hot(data, 'trading_rights')
    data = one_hot(data, 'elevator_equipped')
    data.rename(columns = {'有':'有电梯',"无":"无电梯"},inplace=True)
    data['室'] = data['house_type'].apply(func = lambda x : x.split("室")[0])
    data['厅'] = data['house_type'].apply(func=lambda x: x.split("厅")[0].split("室")[1])
    data['厨'] = data['house_type'].apply(func=lambda x: x.split("厨")[0].split("厅")[1])
    data['卫'] = data['house_type'].apply(func=lambda x: x.split("卫")[0].split("厨")[1])
    data.drop('house_type', axis=1, inplace=True)
    #去除无关变量
    data.drop('region', axis=1, inplace=True)
    data.drop('orientation', axis=1, inplace=True)
    data.drop('elevator_ratio', axis=1, inplace=True)
    data.drop('community', axis=1, inplace=True)

    X_selected, y ,feature_list= feature_selection(data)
    rf = RandomForestRegressor(n_estimators=100, random_state=42)
    X_train, X_test, y_train, y_test = train_test_split(X_selected, y, test_size=0.2, random_state=42)
    rf.fit(X_train, y_train)
    print('Random Forest Training Score: {:.2f}'.format(rf.score(X_train, y_train)))
    print('Random Forest Test Score: {:.2f}'.format(rf.score(X_test, y_test)))


    '''与其他模型进行对比'''
    import xgboost as xgb
    # 训练XGBoost模型
    xgb_model = xgb.XGBRegressor(objective='reg:squarederror', colsample_bytree=0.3, learning_rate=0.1,                           max_depth=5, alpha=10, n_estimators=100)
    xgb_model.fit(X_train, y_train)
    # 评估XGBoost模型
    print('XGBoost Training Score: {:.2f}'.format(xgb_model.score(X_train, y_train)))
    print('XGBoost Test Score: {:.2f}'.format(xgb_model.score(X_test, y_test)))


    from sklearn.svm import SVR
    # 训练SVM模型
    svm_model = SVR(kernel='rbf', C=100, gamma=0.1, epsilon=.1)
    svm_model.fit(X_train, y_train)
    # 评估SVM模型
    print('SVM Training Score: {:.2f}'.format(svm_model.score(X_train, y_train)))
    print('SVM Test Score: {:.2f}'.format(svm_model.score(X_test, y_test)))

    import matplotlib.pyplot as plt

    # 定义得分数据并将其舍入为小数点后两位
    xgb_train_score = round(xgb_model.score(X_train, y_train), 2)
    xgb_test_score = round(xgb_model.score(X_test, y_test), 2)
    rf_train_score = round(rf.score(X_train, y_train), 2)
    rf_test_score = round(rf.score(X_test, y_test), 2)
    svm_train_score = round(svm_model.score(X_train, y_train), 2)
    svm_test_score = round(svm_model.score(X_test, y_test), 2)

    scores = {'XGBoost': xgb_train_score,
              'XGBoost-T': xgb_test_score,
              'RandomF': rf_train_score,
              'RandomF-T)': rf_test_score,
              'SVM': svm_train_score,
              'SVM-T': svm_test_score}

    # 将得分绘制成条形图
    fig, ax = plt.subplots()
    # 添加条形图
    bars = ax.bar(scores.keys(), scores.values())

    # 显示每个条形的具体值
    for bar in bars:
        yval = bar.get_height()
        plt.text(bar.get_x() + 0.3, yval + 0.01, yval, fontsize=8)

    # 调整 x 轴标签字体大小
    plt.xticks(fontsize=8)

    # 添加标题和标签
    ax.set_title('Model Scores')
    ax.set_ylabel('Score')
    ax.set_ylim(0, 1)

    # 显示图形
    plt.show()

    # 创建空DataFrame
    test_data = pd.DataFrame(columns=['built_year', 'area', 'community_average_price', 'house_count',
                                      'average_property_fee', '从化', '南沙', '南海', '增城', '天河', '海珠', '番禺',
                                      '白云',
                                      '花都', '荔湾', '越秀', '黄埔', '中楼层', '低楼层', '高楼层', '框架结构',
                                      '混合结构', '砖木结构',
                                      '砖混结构', '钢混结构', '钢结构', '其他', '毛坯', '简装', '精装', '复式', '平层',
                                      '跃层', '错层',
                                      '动迁安置房', '商品房', '房改房', '私产', '经济适用房', '自建房', '无电梯',
                                      '有电梯', '室', '厅',
                                      '厨', '卫'])

    # assuming your trained model is named `rf_model`
    #predictions = rf.predict(np.array(test_list).reshape(-1,1))
    test_list = ['1990',81.03 ,30968.0 ,3204, 0.8, 0, 0 ,0 ,1, 0, 0 ,1, 0, 0, 0, 1, 0, 0, 1, 0, '3', '2', '1']
    arr = np.array(test_list)
    predictions = rf.predict(arr.reshape(1,-1))
    print(predictions)
    #print(feature_list)
    return rf, feature_list,X_train[0]

def main():

    rf,feature_list,astype_list = data_processing()
    #print(feature_list)


if __name__ == '__main__':
    main()