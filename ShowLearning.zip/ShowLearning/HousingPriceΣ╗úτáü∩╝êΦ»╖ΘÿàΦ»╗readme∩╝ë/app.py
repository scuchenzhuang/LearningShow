from flask import Flask, render_template, redirect, url_for, session,request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask import Flask
from flask_caching import Cache
from openpyxl import load_workbook
from io import BytesIO
from plotly.offline import plot
import plotly.graph_objs as go
from collections import Counter
from collections import defaultdict
from pyecharts.charts import Bar,Pie,Scatter,Grid
from pyecharts import options as opts
from flask import render_template
import numpy as np
import pandas as pd
import 预测模型
app = Flask(__name__)
app.secret_key = 'your_secret_key'
# SQLAlchemy configurations
# MySQL所在主机名
HOSTNAME = "127.0.0.1"
# MySQL监听的端口号，默认3306
PORT = 3306
# 连接MySQL的用户名，自己设置
USERNAME = "root"
# 连接MySQL的密码，自己设置
PASSWORD = "dbuserdbuser"
# MySQL上创建的数据库名称
DATABASE = "HousingPrice"
# 通过修改以下代码来操作不同的SQL比写原生SQL简单很多 --》通过ORM可以实现从底层更改使用的SQL
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{USERNAME}:{PASSWORD}@{HOSTNAME}:{PORT}/{DATABASE}?charset=utf8mb4"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
rf, feature_list, astype_list = 预测模型.data_processing()




# User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True)
    password = db.Column(db.String(50))
    email = db.Column(db.String(50))
    grouptype = db.Column(db.String(50))






@app.route('/')
def index():
    # Check if the user is logged in
    if 'username' in session:
        username = session['username']
        user = User.query.filter_by(username=username).first()
        return render_template('index.html', username=user.username,email=user.email,grouptype=user.grouptype)
    else:
        return redirect(url_for('login'))


# 定义展示和编辑房价数据的路由
@app.route('/show_price_data', methods=['GET'])
def show_price_data():
    # 获取传递的房价数据的 id
    # 如果是 GET 请求，展示指定 id 的房价数据表单页面
    if request.method == 'GET':
        # 查询指定 id 的房价数据
        house_id = request.args.get('id')
        house = House.query.get(house_id)
        # 如果指定 id 的房价数据不存在，返回 404 错误
        if house is None:
            return 'House not found', 404

        # 渲染房价数据表单页面，并传递房价数据
        return render_template('edit_data.html', house=house.to_dict())

    # 定义展示和编辑房价数据的路由
@app.route('/update_price_data', methods=['POST'])
def update_price_data():
    house_id = int(request.form['id'])
    house = House.query.get(house_id)
    if not house:
        return render_template("edit_data.html", message="不存在这样的id")
    house.deal_price = request.form['deal_price']
    house.district = request.form['district']
    house.region = request.form['region']
    house.community = request.form['community']
    house.house_type = request.form['house_type']
    house.floor = request.form['floor']
    house.built_year = request.form['built_year']
    house.architecture = request.form['architecture']
    house.area = request.form['area']
    house.house_structure = request.form['house_structure']
    house.orientation = request.form['orientation']
    house.decoration = request.form['decoration']
    house.elevator_ratio = request.form['elevator_ratio']
    house.elevator_equipped = request.form['elevator_equipped']
    house.trading_rights = request.form['trading_rights']
    house.community_average_price = request.form['community_average_price']
    house.house_count = request.form['house_count']
    house.average_property_fee = request.form['average_property_fee']
    db.session.commit()
    return render_template("edit_data.html", message="修改成功",house=house.to_dict())


@app.route('/get_house', methods=['POST',"GET"])
def get_house():
    if request.method == "GET":
        return render_template("get_house.html")
    # 获取查询参数
    district = request.form.get('district')
    architecture = request.form.get('architecture')
    floor = request.form.get('floor')
    house_type = request.form.get('house_type')

    # 构造查询条件
    query_filters = {}

    if district:
        query_filters['district'] = district

    if architecture:
        query_filters['architecture'] = architecture

    if floor:
        query_filters['floor'] = floor

    if house_type:
        query_filters['house_type'] = house_type
    # 根据查询条件筛选数据
    query = House.query.filter_by(**query_filters)

    # 将数据转换为字典列表
    houses = [house.to_dict() for house in query.all()]

    # 返回数据
    return render_template("get_house.html", houses=houses)


@app.route('/change_password', methods=['POST',"GET"])
def change_password():
    # Check if the user is logged in
    if 'username' not in session:
        return redirect(url_for('login'))
    if request.method == "GET":
        return render_template("change_password.html")
    # Get the current user
    username = session['username']
    user = User.query.filter_by(username=username).first()

    # Check if the old password matches
    old_password = request.form['old_password']
    if old_password != user.password:
        return render_template('change_password.html', success_message='密码修改失败')


    # Update the password
    new_password = request.form['new_password']
    user.password = new_password
    db.session.commit()

    # Return success message
    return render_template('change_password.html', success_message='密码修改成功')



@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        grouptype = request.form['grouptype']
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            return render_template('register.html', message='该用户已存在，请前往登入')

        user = User(username=username, password=password, email=email, grouptype=grouptype)
        db.session.add(user)
        db.session.commit()
        session['username'] = user.username

        return redirect(url_for('index'))
    else:
        return render_template('register.html')
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username, password=password).first()
        if user is not None:
            # Store the username in a session
            session['username'] = user.username
            # Redirect to the homepage if login is successful
            return redirect(url_for('index'))
        else:
            # Show an error message if login is unsuccessful
            error = 'Invalid username or password'
            return render_template('login.html', error=error)
    else:
        return render_template('login.html')

@app.route('/logout')
def logout():
    # Clear the session
    session.clear()
    return redirect(url_for('login'))



# House model
class House(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    deal_price = db.Column(db.Float)
    district = db.Column(db.String(50))
    region = db.Column(db.String(50))
    community = db.Column(db.String(50))
    house_type = db.Column(db.String(50))
    floor = db.Column(db.String(50))
    built_year = db.Column(db.String(50))
    architecture = db.Column(db.String(50))
    area = db.Column(db.Float)
    house_structure = db.Column(db.String(50))
    orientation = db.Column(db.String(50))
    decoration = db.Column(db.String(50))
    elevator_ratio = db.Column(db.String(50))
    elevator_equipped = db.Column(db.String(50))
    trading_rights = db.Column(db.String(50))
    community_average_price = db.Column(db.Float)
    house_count = db.Column(db.Integer)
    average_property_fee = db.Column(db.Float)
    def to_dict(self):
        return {
            'id': self.id,
            'deal_price': self.deal_price,
            'district': self.district,
            'region': self.region,
            'community': self.community,
            'house_type': self.house_type,
            'floor': self.floor,
            'built_year': self.built_year,
            'architecture': self.architecture,
            'area': self.area,
            'house_structure': self.house_structure,
            'orientation': self.orientation,
            'decoration': self.decoration,
            'elevator_ratio': self.elevator_ratio,
            'elevator_equipped': self.elevator_equipped,
            'trading_rights': self.trading_rights,
            'community_average_price': self.community_average_price,
            'house_count': self.house_count,
            'average_property_fee': self.average_property_fee
        }

@app.route('/upload', methods=['POST','GET'])
def upload():
    if request.method == 'GET':
        return render_template('upload.html')
    file = request.files['file']
    file_stream = BytesIO(file.read())
    workbook = load_workbook(file_stream)
    sheet = workbook.active
    data = []
    for row in sheet.iter_rows(min_row=2):
        (deal_price, district, region, community, house_type, floor, built_year, architecture, area,
         house_structure, orientation, decoration, elevator_ratio, elevator_equipped, trading_rights,
         community_average_price, house_count, average_property_fee) = row
        data.append({
            'deal_price': deal_price.value,
            'district': district.value,
            'region': region.value,
            'community': community.value,
            'house_type': house_type.value,
            'floor': floor.value,
            'built_year': built_year.value,
            'architecture': architecture.value,
            'area': area.value,
            'house_structure': house_structure.value,
            'orientation': orientation.value,
            'decoration': decoration.value,
            'elevator_ratio': elevator_ratio.value,
            'elevator_equipped': elevator_equipped.value,
            'trading_rights': trading_rights.value,
            'community_average_price': community_average_price.value,
            'house_count': house_count.value,
            'average_property_fee': average_property_fee.value
        })
    try:
        for item in data:
            house = House(deal_price=item['deal_price'], district=item['district'], region=item['region'],
                          community=item['community'], house_type=item['house_type'], floor=item['floor'],
                          built_year=item['built_year'], architecture=item['architecture'], area=item['area'],house_structure=item['house_structure'], orientation=item['orientation'],decoration=item['decoration'], elevator_ratio=item['elevator_ratio'],
                            elevator_equipped=item['elevator_equipped'], trading_rights=item['trading_rights'],
                            community_average_price=item['community_average_price'], house_count=item['house_count'],
                            average_property_fee=item['average_property_fee'])
            db.session.add(house)
            db.session.commit()
    except:
            db.session.rollback()
            return render_template("upload.html",message = "数据上传失败，请检查文件")
    return render_template("upload.html",message = "数据上传成功，已录入数据库")


@app.route('/upload_house', methods=['POST'])
def upload_house():
    try:
        deal_price = request.form['deal_price']
        district = request.form['district']
        region = request.form['region']
        community = request.form['community']
        house_type = request.form['house_type']
        floor = request.form['floor']
        built_year = request.form['built_year']
        architecture = request.form['architecture']
        area = request.form['area']
        house_structure = request.form['house_structure']
        orientation = request.form['orientation']
        decoration = request.form['decoration']
        elevator_ratio = request.form['elevator_ratio']
        elevator_equipped = request.form['elevator_equipped']
        trading_rights = request.form['trading_rights']
        community_average_price = request.form['community_average_price']
        house_count = request.form['house_count']
        average_property_fee = request.form['average_property_fee']

        house = House(deal_price=deal_price, district=district, region=region, community=community, house_type=house_type, floor=floor, built_year=built_year, architecture=architecture, area=area, house_structure=house_structure, orientation=orientation, decoration=decoration, elevator_ratio=elevator_ratio, elevator_equipped=elevator_equipped, trading_rights=trading_rights, community_average_price=community_average_price, house_count=house_count, average_property_fee=average_property_fee)

        db.session.add(house)
        db.session.commit()
        return render_template("upload.html",message = "数据上传成功，已录入数据库")
    except:
        db.session.rollback()
        return render_template("upload.html",message = "数据上传失败，请检查文件")


#数据可视化模块
@app.route('/averageprice_chart')
def bar_chart():
    houses = House.query.all()

    # Calculate the average price for each district
    district_prices = defaultdict(list)
    for house in houses:
        district_prices[house.district].append(house.deal_price)

    x_values = []
    y_values = []
    for district, prices in district_prices.items():
        x_values.append(district)
        y_values.append(round(sum(prices) / len(prices), 2))
    #y_values_with_unit = [f"{y} w" for y in y_values]
    # Create a bar chart using Pyecharts
    bar_chart = (
        Bar()
        .add_xaxis(x_values)
        .add_yaxis("Average Price", y_values, itemstyle_opts={"color": "blue"})
        .set_global_opts(
            title_opts=opts.TitleOpts(title="广州各区域房价平均值（万元）"),
            xaxis_opts=opts.AxisOpts(name="行政区（万元）"),
            yaxis_opts=opts.AxisOpts(name="区域房价(万元)"),
        )
        .render_embed()  # Generate the HTML code for the chart
    )

    # Render the template with the chart HTML
    return render_template('chart.html', chart_html=bar_chart)

@app.route('/built_year_chart')
def built_year():
    houses = House.query.all()

    # Create a list of year built values
    years = [house.built_year for house in houses]

    # Count the frequency of each year built value
    year_counts = dict(Counter(years))

    # Create a list of year labels and their corresponding counts
    labels = list(year_counts.keys())
    values = list(year_counts.values())

    # Create a bar chart using Pyecharts
    chart = (
        Bar()
        .add_xaxis(labels)
        .add_yaxis("Number of Houses", values, itemstyle_opts={"color": "blue"})
        .set_global_opts(
            title_opts=opts.TitleOpts(title="建筑年代柱状图"),
            xaxis_opts=opts.AxisOpts(name="Year Built"),
            yaxis_opts=opts.AxisOpts(name="Number of Houses")
        )
    )

    # Generate the HTML code for the chart
    chart_html = chart.render_embed()

    # Render the template with the chart HTML
    return render_template('chart.html', chart_html=chart_html)
@app.route('/property_chart')
def property():
    houses = House.query.all()
    # Create a list of property tax and price values
    taxes = [house.average_property_fee for house in houses]
    prices = [house.deal_price for house in houses]

    # Create a scatter chart using Pyecharts
    chart = (
        Scatter()
        .add_xaxis(taxes)
        .add_yaxis("House Prices", prices, label_opts=opts.LabelOpts(is_show=False),
                   itemstyle_opts=opts.ItemStyleOpts(color="blue"))
        .set_series_opts(
            markline_opts=opts.MarkLineOpts(
                data=[opts.MarkLineItem(y=max(prices)), opts.MarkLineItem(y=min(prices))]
            )
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(title="物业费与房价关系图"),
            xaxis_opts=opts.AxisOpts(type_="value", name="Property Tax ($)"),
            yaxis_opts=opts.AxisOpts(type_="value", name="Price ($)")
        )
    )

    # Generate the HTML code for the chart
    chart_html = chart.render_embed()

    # Render the template with the chart HTML
    return render_template('chart.html', chart_html=chart_html)
@app.route('/delete-data', methods=['POST'])
def delete_data():
    id = request.form['id']
    if id:
        house = House.query.get(id)
        if house:
            db.session.delete(house)
            db.session.commit()
            return jsonify({'message': 'Data deleted successfully'}), 200
        else:
            return jsonify({'error': 'Data not found'}), 404
    else:
        return jsonify({'error': 'Invalid data'}), 400

@app.route('/tradingright')
def tradingright():
    houses = House.query.all()
    # Create a list of transaction types
    transactions = [house.trading_rights for house in houses]
    # Count the frequency of each transaction type
    transaction_counts = dict(Counter(transactions))
    # Create a list of transaction type labels and their corresponding counts
    labels = list(transaction_counts.keys())
    values = list(transaction_counts.values())
    # Create a pie chart using Pyecharts
    chart = (
        Pie()
        .add("", [list(z) for z in zip(labels, values)])
        .set_global_opts(
            title_opts=opts.TitleOpts(title="交易权属环形图", pos_top="5%", title_textstyle_opts=opts.TextStyleOpts(font_size=20)),
            legend_opts=opts.LegendOpts(pos_left="left"),
        )
        .set_series_opts(label_opts=opts.LabelOpts(formatter="{b}: {c}"))
    )



    # Generate the HTML code for the chart
    chart_html = chart.render_embed()

    # Render the template with the chart HTML
    return render_template('chart.html', chart_html=chart_html)


@app.route('/area_price_chart')
def area_price():
    houses = House.query.all()
    # Create a list of area and price values
    areas = [house.area for house in houses]
    prices = [house.deal_price for house in houses]
    # Create a scatter chart using Pyecharts
    chart = (
        Scatter()
        .add_xaxis(areas)
        .add_yaxis("House Prices", prices, label_opts=opts.LabelOpts(is_show=False),
                   itemstyle_opts=opts.ItemStyleOpts(color="blue"))
        .set_series_opts(
            markline_opts=opts.MarkLineOpts(
                data=[opts.MarkLineItem(y=max(prices)), opts.MarkLineItem(y=min(prices))]
            )
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(title="面积和房价关系图"),
            xaxis_opts=opts.AxisOpts(type_="value", name="Area (sqft)"),
            yaxis_opts=opts.AxisOpts(type_="value", name="Price ($)"),
        )
    )
    # Generate the HTML code for the chart
    chart_html = chart.render_embed()

    # Render the template with the chart HTML
    return render_template('chart.html', chart_html=chart_html)


@app.route('/floor_distribution_chart')
def floor_distribution():
    houses = House.query.all()

    # Get a list of floor values
    floors = [house.floor for house in houses]

    # Count the frequency of each floor value
    floor_counts = dict(Counter(floors))

    # Create a list of floor labels and their corresponding counts
    labels = list(floor_counts.keys())
    values = list(floor_counts.values())

    # Create a pie chart using Pyecharts
    chart = (
        Pie()
        .add("", [list(z) for z in zip(labels, values)])
        .set_series_opts(label_opts=opts.LabelOpts(formatter="{b}: {c}"))
        .set_global_opts(title_opts=opts.TitleOpts(title="楼层分布情况"))
    )
    # Generate the HTML code for the chart
    chart_html = chart.render_embed()
    # Render the template with the chart HTML
    return render_template('chart.html', chart_html=chart_html)
#随机森林模型
@app.route('/rf_model',methods=['GET','POST'])
def rf_model():
    if request.method == "GET":
        return render_template('rf.html', feature_list = feature_list)
    form_data = request.form
    #test_data = np.array([request.form[feature] for i,feature in enumerate(feature_list)]).astype(astype_list[i])
    test_data = []
    for i,item in enumerate(form_data):
        cur_type = type(astype_list[i])
        test_data.append(cur_type(form_data[item]))
    # do prediction with data
    arr_test = np.array(test_data)
    prediction = rf.predict(arr_test.reshape(1,-1))
    # return prediction as JSON
    return render_template("rf.html",prediction= round(prediction[0], 2))
# 初始化数据库并且添加测试数据
@app.route('/init')
def init():
    # 删除表
    db.drop_all()
    # 创建表
    db.create_all()
    # 添加测试用户
    user1 = User(username='user1', password='123456', email='user1@example.com', grouptype='普通用户')
    user2 = User(username='user2', password='123456', email='user2@example.com', grouptype='管理员')
    db.session.add(user1)
    db.session.add(user2)
    db.session.commit()
    return render_template('login.html')

if __name__ == '__main__':
    app.run(debug=False)
