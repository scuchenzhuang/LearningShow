###    房价预测系统使用说明
*   在终端下，运行以下命令以安装 requirement.txt 文件中列出的所有依赖项
    *   pip install -r requirement.txt
*   在终端，运行db.sql
    *   mysql -u root -p dbuserdbuser < db.sql
