import requests

# 发送GET请求
response = requests.get('http://127.0.0.1:5000/api/tasks')
tasks = response.json()
print('GET /api/tasks')
print(tasks)
print('---')

# 发送POST请求
new_task = {'id': 1, 'title': 'Task 1', 'completed': False}
response = requests.post('http://127.0.0.1:5000/api/tasks', json=new_task)
created_task = response.json()
print('POST /api/tasks')
print(created_task)
print('---')

# 发送PUT请求
updated_task = {'title': '今天不遛狗了，我去撸猫！', 'completed': True}
response = requests.put('http://127.0.0.1:5000/api/tasks/1', json=updated_task)
updated_task = response.json()
print('PUT /api/tasks/1')
print(updated_task)
print('---')

# 发送GET请求
response = requests.get('http://127.0.0.1:5000/api/tasks')
tasks = response.json()
print('GET /api/tasks')
print(tasks)
print('---')

# 发送DELETE请求
response = requests.delete('http://127.0.0.1:5000/api/tasks/1')
print('DELETE /api/tasks/1')
print(response.status_code)
print('---')



# 发送DELETE请求
response = requests.delete('http://127.0.0.1:5000/api/tasks/2')
print('DELETE /api/tasks/2')
print(response.status_code)
print('---')

# 发送DELETE请求
response = requests.delete('http://127.0.0.1:5000/api/tasks/3')
print('DELETE /api/tasks/3')
print(response.status_code)
print('---')

# 发送GET请求
response = requests.get('http://127.0.0.1:5000/api/tasks')
tasks = response.json()
print('GET /api/tasks')
print(tasks)
print('---')