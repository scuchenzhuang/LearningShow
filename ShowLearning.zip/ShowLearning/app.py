from flask import Flask, jsonify, request

app = Flask(__name__)
tasks = [
    {'id': 1, 'title': '遛狗', 'completed': False},
    {'id': 2, 'title': '健身', 'completed': True},
    {'id': 3, 'title': '打球', 'completed': False}
]


@app.route('/api/tasks', methods=['GET'])
def get_tasks():
    return jsonify(tasks)

@app.route('/api/tasks', methods=['POST'])
def create_task():
    new_task = request.json
    tasks.append(new_task)
    return jsonify(new_task), 201

@app.route('/api/tasks/<int:task_id>', methods=['PUT'])
def update_task(task_id):
    task = next((task for task in tasks if task['id'] == task_id), None)
    if not task:
        return jsonify({'error': 'Task not found'}), 404

    task.update(request.json)
    return jsonify(task)

@app.route('/api/tasks/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    task = next((task for task in tasks if task['id'] == task_id), None)
    if not task:
        return jsonify({'error': 'Task not found'}), 404

    tasks.remove(task)
    print(tasks)
    return '', 204

if __name__ == '__main__':
    app.run()
