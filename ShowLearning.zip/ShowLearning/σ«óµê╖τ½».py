import socket

# 创建socket对象
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 服务器地址
server_address = ('localhost', 12344)

# 连接服务器
client_socket.connect(server_address)
print("已连接服务器:", server_address)

while True:
    # 输入句子
    sentence = input("请输入句子: ")

    if sentence:
        # 发送句子给服务器
        client_socket.send(sentence.encode('utf-8'))

        # 接收服务器回复
        reply = client_socket.recv(1024).decode('utf-8')
        print("服务器回复:", reply)
    else:
        break

# 关闭连接
client_socket.close()
