import socket
import random

# 句子列表
sentences = ["只要有恶人存在，我就会变成柯南！—— 工藤新一",
    "真相只有一个！—— 柯南",
    "一个人即使寂寞到绝望，只要还有一点希望，他就可以重生！—— 柯南",
    "不放弃的话，总有一天，你会发现希望！—— 毛利兰",
    "推理是解决问题的根本！—— 灰原哀",
    "就算身体缩小，我的心志永远不会缩小！—— 目暮警部",
    "有了危机感，才会有成长的动力！—— 柯南",

    # 日常
    "只要不放弃，奇迹就会出现！—— 日常",
    "为了友情，就算是九死一生也在所不惜！—— 日常",
    "无论发生什么事情，都要保持一颗平常心！—— 日常",
    "总有一天，我们会找到属于自己的答案！—— 日常",
    "有时候，生活也需要一点点傻劲！—— 樱井樱",
    "一起玩，一起笑，一起悲伤，这就是我们的日常！—— 日常",
    "即使平凡，也要过得有趣！—— 板垣征四郎",

    # 齐木楠雄
    "我是极品美少女齐木楠雄！—— 齐木楠雄",
    "对我来说，再平凡不过的事情，对你们来说就是奇迹了吗？—— 齐木楠雄",
    "别慌，我会帮你解决问题的！—— 齐木楠雄",
    "我不需要超能力，因为我本来就是最强的！—— 齐木楠雄",
    "我只是个普通人，只是没人发现我是个超能力者罢了！—— 阿良良木历",
    "能够享受平凡日常的人，才是最幸福的人！—— 卷六",
    "没有别人的期望，也就没有了烦恼！—— 卷五"]

# 创建socket对象
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 绑定IP地址和端口号
server_address = ('localhost', 12344)
server_socket.bind(server_address)

# 开始监听
server_socket.listen(1)
print("服务器启动，等待客户端连接...")

# 等待客户端连接
client_socket, client_address = server_socket.accept()
print("客户端已连接:", client_address)

while True:
    # 接收客户端发送的数据
    data = client_socket.recv(1024).decode('utf-8')

    if data:
        # 随机选择一个句子作为回复
        reply = random.choice(sentences)

        # 发送回复给客户端
        client_socket.send(reply.encode('utf-8'))
    else:
        break

# 关闭连接
client_socket.close()
server_socket.close()
